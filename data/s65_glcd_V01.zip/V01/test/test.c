#include <inttypes.h>
#include "../glcd/glcd.h"
#include "../glcd/lfsr.h"
#include "../font/nums.h"
#include "../font/f9x14.h"
#include "../font/f15x22.h"
#include "../font/f8x11.h"

// four different lines
void testLines(uint8_t iteration) {

    for (uint8_t i = 0; i < iteration; i++) {
      glcdClearScreen(0);                          // clear only on in clipping rect
      glcdSetColor(0, SCREEN_COLOR);
      glcdSetColor(1, BLACK);
      glcdSetColor(2, GOLD);
      glcdSetColor(3, RED);
      for (glcdCoord_t x = SCREEN_LEFT; x <= SCREEN_RIGHT; x++) {
        glcdSetFgColor(YELLOW);
        glcdLine(x, SCREEN_TOP, x, SCREEN_BOTTOM);
        glcdSetFgColor(GREEN);
        glcdLine(SCREEN_RIGHT - x, SCREEN_TOP, SCREEN_RIGHT - x, SCREEN_BOTTOM);
        glcdSetFgColor(BLUE);
        glcdLine(SCREEN_LEFT, SCREEN_TOP, x, SCREEN_BOTTOM);
        glcdSetFgColor(RED);
        glcdLine(SCREEN_RIGHT, SCREEN_BOTTOM, SCREEN_RIGHT - x + SCREEN_LEFT, SCREEN_TOP);
      }
    }
}


// 255 random lines
void testLines2(uint8_t iteration) {

    for (uint8_t i = 0; i < iteration; i++) {
      glcdClearScreen(0);
      for (uint8_t j = 0; j < 255; j++) {
        glcdSetFgColor(lfsr(16));
        glcdLine(lfsr(7) +2, lfsr(7) +2, lfsr(7) +2, lfsr(7) +2);
      }
    }
}

// animated ellipse shape
void testEllipses(uint8_t iteration) {

   glcdColor_t c[7];

   c[0] = YELLOW;
   c[1] = RED;
   c[2] = BLUE;
   c[3] = GREEN;
   c[4] = YELLOW;
   c[5] = RED;
   c[6] = BLUE;

   int8_t i, j = 0, count, k = 1, d = 1;

   for (; iteration > 0; iteration--) {
     glcdSetBkColor(NONE);
     for (count = 0; count < 3; count++) {
       for (i = 67; i > 0; i -= k) {
         glcdSetFgColor(c[j]);
         glcdSetFgColor(c[j +1]);
         glcdEllipse(65, 65, i, 67 - i);
         glcdSetFgColor(c[j +2]);
         glcdEllipse(65, 65, 67 - i, i);
       }
       if (++j >= 4) {j = 0;}
     }
     for (count = 0; count < 3; count++) {
       for (i = 67; i > 0; i -= k) {
         glcdSetFgColor(c[j]);
         glcdSetBkColor(c[j +1]);
         glcdEllipse(65, 65, i, 67 - i);
         glcdSetBkColor(c[j +2]);
         glcdEllipse(65, 65, 67 - i, i);
       }
       if (++j >= 4) {j = 0;}
     }
     k += d;
     if ((k > 5) | (k == 1)) {d = -d;}
   }
}

// random ellipses and circles with random border-/filling color
void testEllipses2(uint8_t iteration) {

    for (; iteration > 0; iteration--) {
      glcdClearScreen(0);
      for (uint8_t i = 0; i < 255; i++) {
        glcdSetColors(lfsr(16), lfsr(16));
        glcdEllipse(lfsr(7) +3, lfsr(7) +lfsr(5)+lfsr(4), lfsr(6), lfsr(6));
      }
    }
}

// random rectangles with random border-/filling color
void testRects(uint8_t iteration) {

    for (; iteration > 0; iteration--) {
      glcdClearScreen(0);
      for (uint8_t i = 0; i < 255; i++) {
        glcdSetColors(lfsr(16), lfsr(16));
        glcdRectangle(lfsr(7) +3, lfsr(7) +3, 
                  lfsr(7) +3, lfsr(7)+lfsr(5)+lfsr(4));
      }
    }
}

// Rotate a rectangle form source orientation to dest orientation such that
// the rectangle is on display always on same location. Please remember the orientation
// of the display in this library is not relative and thus the clipping rect is relative
// to the current orientation set. This simplify normaly the work with different orientations
// on same code. Means the same source with painting can be directly used with different orientations
// without any changes on coordinates. But for this demonstration we have to take care about this,
// because we want always printing on same display locations with different orientations.
// Follow function is'nt included directly in the library, but could be sometimes important to know.

void glcdRotateRect(glcdRect_t *rect, uint8_t source, uint8_t dest) {

    if ((source & 3) != (dest & 3)) {

      glcdCoord_t x1=0, x2=0, y1=0, y2=0;

      switch (source & 3) {
        case 0: {
          x1 = (*rect).X1;
          y1 = (*rect).Y1;
          x2 = (*rect).X2;
          y2 = (*rect).Y2;
          break;
        }
        case 1: {
          x1 = 175 - (*rect).Y2;
          x2 = 175 - (*rect).Y1;
          y1 = (*rect).X1;
          y2 = (*rect).X2;
          break;
        }
        case 2: {
          x1 = 131 - (*rect).X2;
          x2 = 131 - (*rect).X1;
          y1 = (*rect).Y2 - 1;
          y2 = (*rect).Y1 - 1;
          break;
        }
        case 3: {
          x1 = (*rect).Y1;
          x2 = (*rect).Y2;
          y1 = 131 - (*rect).X2;
          y2 = 131 - (*rect).X1;
          break;
        }
      }

      switch (dest & 3) {
        case 0: {
          (*rect).X1 = x1;
          (*rect).Y1 = y1;
          (*rect).X2 = x2;
          (*rect).Y2 = y2;
          break;
        }
        case 1: {
          (*rect).X1 = y1;
          (*rect).X2 = y2;
          (*rect).Y1 = 131 - x2;
          (*rect).Y2 = 131 - x1;
          break;
        }
        case 2: {
          (*rect).X1 = 131 - x2;
          (*rect).X2 = 131 - x1;
          (*rect).Y1 = y2 + 1;
          (*rect).Y2 = y1 + 1;
          break;
        }
        case 3: {
          (*rect).X1 = 175 - y2;
          (*rect).X2 = 175 - y1;
          (*rect).Y1 = x1;
          (*rect).Y2 = x2;
          break;
        }
      }
    }
}

void glcdNewOrientation(uint8_t orientation) {

    glcdRotateRect(&glcd_Clip, glcd_MemCtrl, orientation);
    glcdSetOrientation(orientation);
}

// display random 4 color font symbols with tranparancy and random rotated by 0,90,180 or 270 degree
void testSymbols(uint8_t iteration) {

    uint8_t mem = glcd_MemCtrl;     // save glcd_MemCtrl, thus orientation in 2 LSB's

    glcd_Flags.AutoLineFeed = 0;

    glcdSelectFont(nums, 0);        // font is stored in FLASH, thus no need for own read callback
    glcdSetBkColor(NONE);
    for (; iteration > 0; iteration--) {
      glcdClearScreen(0);
      for (uint8_t i = 0; i < 255; i++) {
        glcdNewOrientation(lfsr(2));
        glcdSetColor(1, lfsr(16));
        glcdSetColor(2, lfsr(16));
        glcdSetColor(3, lfsr(16));
        glcdMoveTo(lfsr(7), lfsr(7)+lfsr(5)+lfsr(4));
        glcdDrawChar(lfsr(4) % 11 + 32);
      }
    }
    glcdNewOrientation(mem);
}



// print text centered horizontal and vertical into bounds r
// demontrate the use of glcdCharsWidth()
void glcdPrintCenter(glcdRect_t r, char *text, uint8_t InFlashStored) {

    r.X1 += (r.X2 - r.X1 - glcdCharsWidth(text, InFlashStored)) / 2;
    r.Y1 += (r.Y2 - r.Y1 - glcd_FontHeight) / 2;
    glcdMoveTo(r.X1, r.Y1);
    glcdPrint(text, InFlashStored);
}


// demontrate own font read callback
uint8_t myRead(glcdFontData_t index) {

    return(pgm_read_byte(f9x14 + index));
}

void demoScreen(void)
{
   glcdRect_t r;
   
  //
  // draw a frame
  //
   #define LT 5  // frame line thickness
   #define HT 50 // inner height of the frame
   // inner area of the frame
   glcdSetRect(r, 15, 15, SCREEN_WIDTH-15, 15+HT);

   // frame colors
   glcdSetFgColor(RGB(0x00, 0x80, 0x00));
   glcdSetFrColor(RGB(0x00, 0x80, 0x00));
   glcdSetBkColor(RGB(0x00, 0x80, 0x00));
   
   glcdRectangle(r.X1-LT, r.Y1-LT, r.X2+LT, r.Y1);
   glcdRectangle(r.X1-LT, r.Y1,    r.X1,    r.Y2);
   glcdRectangle(r.X1-LT, r.Y2,    r.X2+LT, r.Y2+LT);
   glcdRectangle(r.X2, r.Y1,       r.X2+LT, r.Y2+LT);


// fill inner frame
//   glcdSetBkColor(BLUE);
//   glcdRectangle(r.X1, r.Y1, r.X2, r.Y2);


   // write Text into the frame
   glcdSetFgColor(BLUE);
   glcdSetFrColor(BLUE);
   glcdSetBkColor(SCREEN_COLOR);

   glcdSetRect(r, 15, 15, SCREEN_WIDTH-15, 15+18);
   glcdMoveTo(r.X1 + 2, r.Y1 + 2);
   glcdSelectFont(f9x14, 0);           // font is stored in FLASH, demontrate read callback
   glcdPrintCenter(r, PSTR("glcd for"), 1);

   glcdSetFgColor(RGB(0xFF, 0x00, 0x00));
   glcdSetFrColor(RGB(0x00, 0x10, 0xFF));
   glcdSetBkColor(SCREEN_COLOR);

   glcdSetRect(r, 15, 15+18, SCREEN_WIDTH-15, 15+HT);
   glcdMoveTo(r.X1 + 2, r.Y1 + 2);
   glcdSelectFont(f15x22, 0);           // font is stored in FLASH, demontrate read callback
   glcdPrintCenter(r, PSTR("S65-Display"), 1);


  // draw note sheet
  #define TOP 90
  #define GRID 8
  
  glcdSetColors(BLACK, NONE);
  
  glcdLine(30, TOP, SCREEN_WIDTH-30, TOP);
  glcdLine(30, TOP+1*GRID, SCREEN_WIDTH-30, TOP+1*GRID);
  glcdLine(30, TOP+2*GRID, SCREEN_WIDTH-30, TOP+2*GRID);
  glcdLine(30, TOP+3*GRID, SCREEN_WIDTH-30, TOP+3*GRID);
  glcdLine(30, TOP+4*GRID, SCREEN_WIDTH-30, TOP+4*GRID);

  glcdSetColors(BLACK, BLACK);
  // tone C
  glcdEllipse(40, TOP+5*GRID, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdLine(40-GRID/2-4, TOP+5*GRID, 40+GRID/2+4, TOP+5*GRID);
  glcdLine(40+GRID/2+1, TOP+5*GRID, 40+GRID/2+1, TOP+5*GRID-4*GRID); 
  // tone E
  glcdEllipse(55, TOP+4*GRID, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdLine(55+GRID/2+1, TOP+4*GRID, 55+GRID/2+1, TOP+4*GRID-4*GRID); 
  // tone G
  glcdEllipse(70, TOP+3*GRID, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdLine(70+GRID/2+1, TOP+3*GRID, 70+GRID/2+1, TOP+3*GRID-4*GRID); 
  // dur cEGC
  glcdSetColors(RGB(0x80,0,0), RGB(0x80,0,0));
  glcdEllipse(85, TOP+1*GRID+GRID/2, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdLine(85-GRID/2-1, TOP+1*GRID+GRID/2, 85-GRID/2-1, TOP+1*GRID+GRID/2+4*GRID); 

  glcdEllipse(85, TOP+3*GRID+0*GRID/2, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdEllipse(85, TOP+4*GRID+0*GRID/2, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdEllipse(85, TOP+5*GRID+0*GRID/2, GRID/2+1, GRID/2-1);   // ellipse at x,y with radius a,b
  glcdLine(85-GRID/2-4, TOP+5*GRID, 85+GRID/2+4, TOP+5*GRID);




   glcdSetColors(BLACK, NONE);
   glcdSetRect(r, 15, 145, SCREEN_WIDTH-15, 145+20);
   glcdMoveTo(r.X1 + 2, r.Y1 + 2);
   glcdSelectFont(f9x14, 0);           // font is stored in FLASH, demontrate read callback
   glcdPrintCenter(r, PSTR("by Christian Kranz"), 1);


   glcdSetColors(BLACK, NONE);
   glcdSetRect(r, 15, 158, SCREEN_WIDTH-15, 158+20);
   glcdMoveTo(r.X1 + 2, r.Y1 + 2);
   glcdSelectFont(f8x11, 0);           // font is stored in FLASH, demontrate read callback
   glcdPrintCenter(r, PSTR("cnkz@yahoo.com"), 1);


}

// paint on the four possible orientation, as shown the coordinates are always the same
void testOrientation(void) {

    uint8_t mem = glcd_MemCtrl;          // save glcd_MemCtrl
    glcdFlags_t flags = glcd_Flags;      // save glcd_Flags

    glcd_Flags.All = 0;                  // all bits off, no clipping, no fixed font and no autolinefeed

    glcdRect_t r;
    glcdSetRect(r, 1, 1, 64, 64);

    glcdClearScreen(0);
    glcdSelectFont(0, myRead);           // font is stored in FLASH, demontrate read callback

    glcdSetOrientation(0);
    glcdSetColors(BLACK, NONE);
    glcdRectangle(r.X1, r.Y1, r.X2, r.Y2);
    glcdLine(r.X1, r.Y1, r.X2, r.Y2);
    glcdCircle(r.X1, r.Y1, 20);
    glcdMoveTo(r.X1 + 2, r.Y1 + 2);
    glcdPrintCenter(r, PSTR("0 Grad"), 1);
/*
    glcdSetOrientation(1);
    glcdSetColors(RED, NONE);
    glcdRectangle(r.X1, r.Y1, r.X2, r.Y2);
    glcdLine(r.X1, r.Y1, r.X2, r.Y2);
    glcdCircle(r.X1, r.Y1, 20);
    glcdMoveTo(r.X1 + 2, r.Y1 + 2);
    glcdPrintCenter(r, PSTR("90 Grad"), 1);

    glcdSetOrientation(2);
    glcdSetColors(GREEN, NONE);
    glcdRectangle(r.X1, r.Y1, r.X2, r.Y2);
    glcdLine(r.X1, r.Y1, r.X2, r.Y2);
    glcdCircle(r.X1, r.Y1, 20);
    glcdMoveTo(r.X1 + 2, r.Y1 + 2);
    glcdPrintCenter(r, PSTR("180 Grad"), 1);

    glcdSetOrientation(3);
    glcdSetColors(YELLOW, NONE);
    glcdRectangle(r.X1, r.Y1, r.X2, r.Y2);
    glcdLine(r.X1, r.Y1, r.X2, r.Y2);
    glcdCircle(r.X1, r.Y1, 20);
    glcdMoveTo(r.X1 + 2, r.Y1 + 2);
    glcdPrintCenter(r, PSTR("270 Grad"), 1);
*/
    glcdWait(2000);       // 2 seconds
    glcd_Flags = flags;
    glcdSetOrientation(mem);
}

// paint own bitmaps
void testBitmaps(void) {
/*
    uint8_t Bitmap[512];
    glcdCoord_t width = glcd_Clip.X2 - glcd_Clip.X1 +1;
    glcdCoord_t height = glcd_Clip.Y2 - glcd_Clip.Y1 +1;
    int16_t i,j;

    for (i = 0; i < 512; i++) {      // create a bitmap
      Bitmap[i] = i * 2;
    }

    glcdSetAddr(glcd_Clip.X1, glcd_Clip.Y1, glcd_Clip.X2, glcd_Clip.Y2);  // bounds of bitmap on screen

    for (i = 0; i < 256; i++) {
      for (j = 0; j < height; j++) {
        glcdDisplayBuffer(&Bitmap[i + j], width, 0);
      }
    }
*/
}

void glcdRandomClipRect(void) {

    while (1) {
      glcdSetRect(glcd_Clip, lfsr(7) +3, lfsr(7) +3, lfsr(7)+3, lfsr(7)+lfsr(5)+lfsr(4));
      if ((glcd_Clip.X1 < glcd_Clip.X2) & (glcd_Clip.Y1 < glcd_Clip.Y2)) {break;}
    }
}

int main(void) {
#define cnt  1

#ifndef USE_AUTOINIT
    glcdDisplayInit();
#endif
  
    glcdClearScreen(1);
//    glcdDisplayOn();

    uint8_t o = 0;

    demoScreen();

    while (1) {

//      glcdSetOrientation(o++);         // next orientation
//     glcdClearScreen(1);              // clear screen, ignore clipping


/*

// some tests with known parameters to check if lib is correct working
     glcdRectangle(10,100,20,140);
     
     glcdLine(0, 0, 40, 20);

     glcdLine(80, 80, 40, 40);
     glcdLine(82, 82, 120, 40);
     glcdLine(84, 84, 40, 120);
     glcdLine(86, 86, 120, 120);


//      glcdRandomClipRect();


      glcd_Flags.Clipping = 0;         // deactivate clipping
      glcdSetColor(0, BLACK);
      glcdSetColor(2, BLACK);
      glcdSetColor(3, NONE);
      glcdFrame(glcd_Clip.X1 -2, glcd_Clip.Y1 -2, glcd_Clip.X2 +2, glcd_Clip.Y2 +2);


      glcd_Flags.Clipping = 1;         // activate clipping

      testRects(cnt);
      testLines2(cnt);
      testLines(cnt);
      testEllipses(cnt);
      testEllipses2(cnt);

      testSymbols(cnt);
      testBitmaps();

      testOrientation();

      glcdRandomClipRect();
*/
    }
}

