This is a link library for the Siemens S65, M65, SX65 and RX65 mobile phone display.

This port copyright 2005 by Christian Kranz.

Based on the glcd copyright 2004 Hagen Reddmann, HaReddmann at T-Online dot de


The S65-Display is a 132x176x65536 color display.
The display use a slave SPI communication
The controller is unknown and can be used with an SPI clock up to 13 MHz. 
The software was used with an ATmega128 at 8MHz SPI clock.


The graphic library is for WinAVR C compiler, but use only gcc assembler source, handmade.


What supports the library ?
- colors
- pixel setting
- lines
- rectangles with border and filling, transparent and full color
- ellipses and circles with border and filling, transparent and full color
- proportional and fixed fonts with multiple colors
- fonts are highly compressed with an table based RLE coding, like a mini Huffmann
- fontroutines use an separate window for display texts (glcd_Window)
- a full featured font creator for MS Window is included
- with fonts it is easy possible to design own bitmaps and icons with transparency
- all font routines such as glcdPrint() can work on nullterminated strings stored in Flash or RAM
- the font data access can be controlled trough own callbacks to support external I2C EEPROMs or other external memories,
  thus there is no need to store large fonts in flash
- all display operation can be truncated with a clipping rect
- all display operation supports transparency
- 65536 color modes
- own bitmap data can be used
- with some hopefully small changes on the base display functions in glcd00.S it should be easily possible to support 
  other controllers, mainly all highlevel routines such as glcdLine(), glcdEllipse() are hardware independend.
- display resolution can be upto 254x254 without any changes

- inculded are a LFSR-SG (linear feedback shift register shrinking generator) as random generator with period 2**63-2
- this RNG is faster, stronger and far more resource fiendly as the gcc inbuild LCG rand() function
- i have included 2x 1000 random and certified irreducible polynomials for the LFSR
 

Whats not supported ?
- the library don't use double buffering of display RAM, otherwise we need 46 KByte SRAM
- the S65-Display don't support reading of internal display RAM, thus any operation, such as pixel XOR'ing, 
  that need reading of display can't be supported
- the adressspace for the font routines is assumed to 16bit and don't support 24bits directly. But with installing an own font read callback there
  exists the possibility to access any memory space in chunks of 64Kb. Thus take care on useing fonts on MCU's with 128 Kb flash.
- one font can't and must not excide 64Kb.
- i can't give expensive support, thus use the lib as is without any warrenties


IMPORTANT!
  please remember the library use hardware SPI and you have to ensure that ~SS Pin is configured as output or is driven high to ensure SPI
  Master. Best choice, with single Master SPI, is to use ~SS Pin as ~CS for the Nokia LCD. But sometimes on ATmega8 as example the ~SS Pin is
  equal to OCR1B and we want to use this Pin as PWM Output. So far as this Pin is an output there exists no problems.


best regards, Christian&Hagen
