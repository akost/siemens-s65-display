/* ***********************************************************************
**
**  Copyright (C) 2005  Christian Kranz
**
**  Siemens S65 Display Control for LPH display
**
*********************************************************************** */
/*********************************************
* Chip type           : ATMEGA128
* Clock frequency     : clock 16 MHz
*********************************************/
#include <avr/io.h>
#include <inttypes.h>

#include "disp.h"


int main(void)
{
  uint8_t i;

  // backlight PWM generation
  // use timer 2 in fast PWM mode for this
  PORTB &= ~_BV(PB7);  // clear port before enable
  DDRB |= _BV(PB7);  // will be used for OC2, must be output
  TCCR2 = _BV(WGM21) | _BV(WGM20) | _BV(COM21) | _BV(CS20);
  TCNT2=0x00;
  OCR2=120;
  
  char txt[]="gruenes Display";

  port_init();

  lcd_init_c();
  backcolor=0x0780;
  textcolor=0x0000;
  fill_screen(0x0780);

  i=0;
  while (txt[i]!=0)
  {
    put_char(30+i*CHAR_W,60,txt[i],0);   //  0 deg. rotated
    put_char(5+i*CHAR_W,10,txt[i],1);   // 90 deg. rotated
    i++;
  }

  while (1) 
  {

  }
  return(0);	  
}

